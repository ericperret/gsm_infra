// =============================================================================
// Fichier  : sync-daemon.js
// Projet   : BSS Opérateur MCC=547 – Synchronisation multi-sites
// Rôle     : Démon Node.js – synchronise le BSS local ↔ serveur central
//            Déclenché dès que WireGuard est UP (tunnel 10.10.0.X)
// Date     : 2026-05-26
// Version  : 1.0.0
// Usage    : node sync-daemon.js  (ou service systemd bss-sync)
// Mode     :
//   SITE    → pousse la sync_queue vers le central, tire les mises à jour
//   CENTRAL → reçoit les push des sites (via l'API), expose /api/sync/*
// =============================================================================

'use strict';

// ── Chargement .env ──────────────────────────────────────────
const fs   = require('fs');
const path = require('path');
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    fs.readFileSync(envPath, 'utf8').split('\n').forEach(line => {
        const clean = line.trim();
        if (!clean || clean.startsWith('#')) return;
        const eq  = clean.indexOf('=');
        if (eq < 0) return;
        const key = clean.slice(0, eq).trim();
        const val = clean.slice(eq + 1).trim().replace(/^["']|["']$/g, '');
        if (!(key in process.env)) process.env[key] = val;
    });
}

const { Pool } = require('pg');
const http     = require('http');
const https    = require('https');

// ── Configuration ─────────────────────────────────────────────
const CFG = {
    // Identité de ce nœud
    SITE_ID       : parseInt(process.env.BSS_SITE_ID    || '0', 10),
    EST_CENTRAL   : process.env.BSS_EST_CENTRAL === 'true',
    SYNC_TOKEN    : process.env.BSS_SYNC_TOKEN  || '',

    // Adresse du serveur central (WireGuard)
    CENTRAL_HOST  : process.env.BSS_CENTRAL_HOST || '10.10.0.1',
    CENTRAL_PORT  : parseInt(process.env.BSS_CENTRAL_PORT || '3000', 10),
    CENTRAL_API   : process.env.BSS_CENTRAL_API  || 'http://10.10.0.1:3000/api',

    // WireGuard – IP à pinguer pour détecter le tunnel
    WG_PEER_IP    : process.env.BSS_WG_PEER_IP   || '10.10.0.1',

    // Intervalles (secondes)
    CHECK_INTERVAL: parseInt(process.env.BSS_CHECK_INTERVAL || '30',  10),
    SYNC_INTERVAL : parseInt(process.env.BSS_SYNC_INTERVAL  || '120', 10),
    RETRY_MAX     : parseInt(process.env.BSS_RETRY_MAX       || '5',   10),

    // Batch
    BATCH_SIZE    : parseInt(process.env.BSS_BATCH_SIZE || '100', 10),
};

// ── Pool PostgreSQL local ─────────────────────────────────────
const pool = new Pool({
    host:     process.env.DB_HOST || 'localhost',
    port:     parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_NAME || 'bss_operateur',
    user:     process.env.DB_USER || 'bss_admin',
    password: process.env.DB_PASS,
    max: 5,
});

// ── Logger ────────────────────────────────────────────────────
const LOG_FILE = '/var/log/bss_sync.log';
function log(level, msg, data = null) {
    const line = `[${new Date().toISOString()}] [${level}] [site:${CFG.SITE_ID}] ${msg}${data ? ' ' + JSON.stringify(data) : ''}`;
    console.log(line);
    try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch {}
}
const info  = (m, d) => log('INFO',  m, d);
const warn  = (m, d) => log('WARN',  m, d);
const error = (m, d) => log('ERROR', m, d);
const ok    = (m, d) => log('OK',    m, d);

// ── Détection WireGuard UP via TCP connect ────────────────────
function tunnelUp() {
    return new Promise(resolve => {
        const s = require('net').createConnection(
            { host: CFG.CENTRAL_HOST, port: CFG.CENTRAL_PORT, timeout: 4000 }
        );
        s.on('connect', () => { s.destroy(); resolve(true);  });
        s.on('error',   () => { s.destroy(); resolve(false); });
        s.on('timeout', () => { s.destroy(); resolve(false); });
    });
}

// ── Requête HTTP vers l'API centrale ─────────────────────────
function apiCall(method, path, body = null) {
    return new Promise((resolve, reject) => {
        const bodyStr = body ? JSON.stringify(body) : null;
        const opts = {
            hostname: CFG.CENTRAL_HOST,
            port:     CFG.CENTRAL_PORT,
            path:     `/api${path}`,
            method,
            headers: {
                'Content-Type':    'application/json',
                'X-Sync-Token':    CFG.SYNC_TOKEN,
                'X-Site-Id':       String(CFG.SITE_ID),
                ...(bodyStr ? { 'Content-Length': Buffer.byteLength(bodyStr) } : {}),
            },
            timeout: 15000,
        };
        const req = http.request(opts, res => {
            let raw = '';
            res.on('data', c => raw += c);
            res.on('end', () => {
                try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); }
                catch { resolve({ status: res.statusCode, body: raw }); }
            });
        });
        req.on('error',   reject);
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
        if (bodyStr) req.write(bodyStr);
        req.end();
    });
}

// ── Positionner le GUC de réplication (désactive les triggers) ─
async function setReplicationMode(client, on) {
    await client.query(`SET LOCAL bss.sync_replication_mode = '${on ? 'on' : 'off'}'`);
}
async function setSiteId(client, id) {
    await client.query(`SET LOCAL bss.current_site_id = '${id}'`);
}

// =============================================================================
// MODE SITE — PUSH : envoyer la sync_queue vers le central
// =============================================================================
async function pushTocentral() {
    const client = await pool.connect();
    let nb_ok = 0, nb_err = 0, nb_conflit = 0;
    const debut = Date.now();
    try {
        // Récupérer un batch en attente ou en erreur (< RETRY_MAX tentatives)
        const { rows: items } = await client.query(
            `SELECT * FROM sync_queue
             WHERE id_site = $1
               AND statut IN ('EN_ATTENTE','ERREUR')
               AND nb_tentatives < $2
             ORDER BY date_creation ASC
             LIMIT $3
             FOR UPDATE SKIP LOCKED`,
            [CFG.SITE_ID, CFG.RETRY_MAX, CFG.BATCH_SIZE]
        );

        if (!items.length) { return { nb_ok: 0, nb_err: 0, nb_conflit: 0 }; }

        info(`PUSH – ${items.length} entrées à envoyer`);

        // Marquer EN_COURS
        const ids = items.map(r => r.id_sync);
        await client.query(
            `UPDATE sync_queue SET statut = 'EN_COURS', derniere_tentative = NOW(),
             nb_tentatives = nb_tentatives + 1
             WHERE id_sync = ANY($1)`,
            [ids]
        );

        // Envoyer en batch
        let result;
        try {
            result = await apiCall('POST', '/sync/push', {
                site_id: CFG.SITE_ID,
                items:   items.map(r => ({
                    id_sync:     r.id_sync,
                    table_cible: r.table_cible,
                    operation:   r.operation,
                    record_id:   r.record_id,
                    payload:     r.payload,
                    date_creation: r.date_creation,
                })),
            });
        } catch (err) {
            // Réseau KO → remettre EN_ATTENTE
            await client.query(
                `UPDATE sync_queue SET statut = 'EN_ATTENTE' WHERE id_sync = ANY($1)`, [ids]
            );
            error('PUSH réseau KO', { err: err.message });
            return { nb_ok: 0, nb_err: items.length, nb_conflit: 0 };
        }

        if (result.status !== 200 && result.status !== 201) {
            await client.query(
                `UPDATE sync_queue SET statut = 'ERREUR',
                 message_erreur = $2 WHERE id_sync = ANY($1)`,
                [ids, `HTTP ${result.status}`]
            );
            error('PUSH HTTP KO', { status: result.status });
            return { nb_ok: 0, nb_err: items.length, nb_conflit: 0 };
        }

        // Traiter les résultats item par item
        const resultats = result.body?.data?.resultats || [];
        for (const r of resultats) {
            if (r.statut === 'OK') {
                await client.query(
                    `UPDATE sync_queue SET statut = 'SYNCED', date_sync = NOW(),
                     central_id = $2 WHERE id_sync = $1`,
                    [r.id_sync, r.central_id || null]
                );
                nb_ok++;
            } else if (r.statut === 'CONFLIT') {
                await client.query(
                    `UPDATE sync_queue SET statut = 'CONFLIT',
                     message_erreur = $2 WHERE id_sync = $1`,
                    [r.id_sync, r.detail || 'Conflit']
                );
                nb_conflit++;
            } else {
                await client.query(
                    `UPDATE sync_queue SET statut = 'ERREUR',
                     message_erreur = $2 WHERE id_sync = $1`,
                    [r.id_sync, r.detail || 'Erreur centrale']
                );
                nb_err++;
            }
        }

        return { nb_ok, nb_err, nb_conflit };
    } finally {
        client.release();
    }
}

// =============================================================================
// MODE SITE — PULL : récupérer les mises à jour du central
// =============================================================================
async function pullFromCentral() {
    // Récupérer le timestamp de la dernière sync réussie
    const { rows } = await pool.query(
        `SELECT MAX(date_fin) AS last FROM sync_log
         WHERE id_site = $1 AND direction IN ('PULL','FULL') AND statut = 'OK'`,
        [CFG.SITE_ID]
    );
    const since = rows[0]?.last || '2020-01-01T00:00:00Z';

    let result;
    try {
        result = await apiCall('GET',
            `/sync/pull?site_id=${CFG.SITE_ID}&since=${encodeURIComponent(since.toISOString ? since.toISOString() : since)}`
        );
    } catch (err) {
        error('PULL réseau KO', { err: err.message });
        return { nb_recus: 0 };
    }

    if (result.status !== 200) {
        error('PULL HTTP KO', { status: result.status });
        return { nb_recus: 0 };
    }

    const items   = result.body?.data?.items || [];
    if (!items.length) return { nb_recus: 0 };

    info(`PULL – ${items.length} mises à jour reçues`);

    const client = await pool.connect();
    let nb_recus = 0;
    try {
        await client.query('BEGIN');
        // Désactiver les triggers de sync pendant la réplication
        await setReplicationMode(client, true);

        for (const item of items) {
            try {
                await _applyItem(client, item);
                nb_recus++;
            } catch (err) {
                warn(`PULL – erreur application item ${item.table_cible}#${item.record_id}`, { err: err.message });
            }
        }

        await client.query('COMMIT');
    } catch (err) {
        await client.query('ROLLBACK');
        error('PULL transaction KO', { err: err.message });
    } finally {
        client.release();
    }

    return { nb_recus };
}

// Appliquer un item reçu du central (UPSERT ou DELETE)
async function _applyItem(client, item) {
    const { table_cible, operation, record_id, payload } = item;

    // Tables autorisées (whitelist)
    const TABLES_OK = ['abonnes','sims','numeros','profils','evenements','alertes_cbs'];
    if (!TABLES_OK.includes(table_cible)) {
        warn(`PULL – table non autorisée : ${table_cible}`);
        return;
    }

    if (operation === 'D') {
        // DELETE
        const pkCol = `id_${table_cible === 'evenements' ? 'evenement' : table_cible.slice(0, -1)}`;
        await client.query(`DELETE FROM ${table_cible} WHERE ${pkCol} = $1`, [record_id]);
        return;
    }

    // INSERT ou UPDATE → UPSERT
    const cols   = Object.keys(payload).filter(k => k !== 'id_sync');
    const vals   = cols.map(c => payload[c]);
    const sets   = cols.map((c, i) => `${c} = $${i + 1}`);
    const pkCol  = cols[0];  // première colonne = PK

    // Upsert générique
    await client.query(
        `INSERT INTO ${table_cible} (${cols.join(',')})
         VALUES (${cols.map((_,i) => `$${i+1}`).join(',')})
         ON CONFLICT (${pkCol})
         DO UPDATE SET ${sets.join(', ')}`,
        vals
    );
}

// =============================================================================
// BOUCLE PRINCIPALE
// =============================================================================
let _syncInProgress = false;
let _lastTunnelState = null;

async function syncCycle() {
    if (_syncInProgress) return;
    _syncInProgress = true;
    const debut = Date.now();

    try {
        // 1. Vérifier le tunnel WireGuard
        const up = await tunnelUp();

        if (up !== _lastTunnelState) {
            info(up ? '✓ Tunnel WireGuard UP – sync activée' : '✗ Tunnel WireGuard DOWN – sync suspendue');
            _lastTunnelState = up;
        }

        if (!up) return;

        // 2. PUSH – envoyer la queue locale
        const pushResult = await pushTocentral();

        // 3. PULL – recevoir les mises à jour centrales
        const pullResult = await pullFromCentral();

        const duree = Date.now() - debut;
        const hasData = pushResult.nb_ok + pushResult.nb_err + pullResult.nb_recus > 0;

        if (hasData || pushResult.nb_conflit > 0) {
            // Logger la session
            await pool.query(
                `INSERT INTO sync_log (id_site, direction, statut, nb_envoyes, nb_recus, nb_conflits, nb_erreurs, duree_ms, date_fin)
                 VALUES ($1, 'FULL', $2, $3, $4, $5, $6, $7, NOW())`,
                [
                    CFG.SITE_ID,
                    pushResult.nb_err > 0 ? 'PARTIEL' : 'OK',
                    pushResult.nb_ok,
                    pullResult.nb_recus,
                    pushResult.nb_conflit,
                    pushResult.nb_err,
                    duree,
                ]
            );

            // Mettre à jour la date de dernière sync sur le site
            await pool.query(
                `UPDATE sites SET derniere_sync = NOW() WHERE id_site = $1`,
                [CFG.SITE_ID]
            );

            ok(`Sync terminée`, {
                push_ok: pushResult.nb_ok,
                push_err: pushResult.nb_err,
                conflits: pushResult.nb_conflit,
                pull: pullResult.nb_recus,
                duree_ms: duree,
            });
        }

    } catch (err) {
        error('Cycle sync KO', { err: err.message });
    } finally {
        _syncInProgress = false;
    }
}

// =============================================================================
// ENDPOINTS API sync – montés sur le serveur HTTP principal (bss-api)
// Ces routes sont enregistrées dans server.js via require('./sync-daemon')
// =============================================================================
// Exposés par le serveur central uniquement :
//   POST /api/sync/push  ← reçoit un batch du site
//   GET  /api/sync/pull  ← retourne les mises à jour depuis ?since=
//   GET  /api/sync/status← état global de toutes les syncs

async function handleSyncPush(req, res) {
    const { parseBody, sendOK, sendCreated, send400, send500 } = require('./lib/utils');
    try {
        // Vérification token
        const token = req.headers['x-sync-token'];
        if (!token || token !== CFG.SYNC_TOKEN) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: false, error: 'Token invalide' }));
            return;
        }

        const body    = await parseBody(req);
        const siteId  = parseInt(req.headers['x-site-id'] || body.site_id, 10);
        const items   = body.items || [];

        if (!items.length) { sendOK(res, { resultats: [] }); return; }

        // Vérifier que le site existe
        const { rows: siteRows } = await pool.query(
            `SELECT id_site FROM sites WHERE id_site = $1`, [siteId]
        );
        if (!siteRows.length) { send400(res, `Site inconnu : ${siteId}`); return; }

        const client  = await pool.connect();
        const resultats = [];
        try {
            await client.query('BEGIN');
            await setReplicationMode(client, true);

            for (const item of items) {
                try {
                    // Détecter les doublons (même id_sync déjà reçu)
                    const dup = await client.query(
                        `SELECT id_sync FROM sync_queue WHERE id_site = $1 AND id_sync = $2`,
                        [siteId, item.id_sync]
                    );
                    if (dup.rows.length) {
                        resultats.push({ id_sync: item.id_sync, statut: 'OK', central_id: item.id_sync, detail: 'Doublon ignoré' });
                        continue;
                    }

                    await _applyItem(client, item);
                    resultats.push({ id_sync: item.id_sync, statut: 'OK', central_id: item.id_sync });
                } catch (err) {
                    resultats.push({ id_sync: item.id_sync, statut: 'ERREUR', detail: err.message });
                }
            }

            // Mise à jour dernière_sync du site
            await client.query(
                `UPDATE sites SET derniere_sync = NOW() WHERE id_site = $1`, [siteId]
            );

            await client.query('COMMIT');
        } catch (err) {
            await client.query('ROLLBACK');
            send500(res, err); return;
        } finally { client.release(); }

        info(`PUSH reçu du site ${siteId} – ${resultats.filter(r=>r.statut==='OK').length}/${items.length} OK`);
        sendCreated(res, { resultats });

    } catch (err) { send500(res, err); }
}

async function handleSyncPull(req, res) {
    const { sendOK, send400, send500 } = require('./lib/utils');
    try {
        const siteId = parseInt(req.query?.site_id, 10);
        const since  = req.query?.since || '2020-01-01T00:00:00Z';

        if (!siteId) { send400(res, 'site_id requis'); return; }

        // Récupérer toutes les modifications depuis "since" qui ne viennent pas de ce site
        const TABLES = ['abonnes','sims','numeros','profils','evenements','alertes_cbs'];
        const items  = [];

        for (const table of TABLES) {
            const pkCol = table === 'evenements' ? 'id_evenement'
                        : table === 'alertes_cbs' ? 'id_alerte'
                        : `id_${table.slice(0,-1)}`;
            try {
                const { rows } = await pool.query(
                    `SELECT * FROM ${table}
                     WHERE date_modification > $1
                       AND (id_site IS NULL OR id_site != $2)
                     ORDER BY date_modification ASC
                     LIMIT 500`,
                    [since, siteId]
                );
                rows.forEach(r => items.push({
                    table_cible: table,
                    operation:   'U',
                    record_id:   r[pkCol],
                    payload:     r,
                }));
            } catch {}  // table peut ne pas avoir date_modification
        }

        sendOK(res, { items, since, count: items.length });
    } catch (err) { send500(res, err); }
}

async function handleSyncStatus(req, res) {
    const { sendOK, send500 } = require('./lib/utils');
    try {
        const { rows } = await pool.query('SELECT * FROM fn_sync_stats()');
        sendOK(res, {
            central: CFG.EST_CENTRAL,
            tunnel_up: _lastTunnelState,
            sites: rows,
        });
    } catch (err) { send500(res, err); }
}

// =============================================================================
// DÉMARRAGE
// =============================================================================
if (CFG.SITE_ID === 0 && !CFG.EST_CENTRAL) {
    error('BSS_SITE_ID non configuré dans .env – démon arrêté');
    process.exit(1);
}

info(`Démon sync BSS démarré`, {
    site_id:     CFG.SITE_ID,
    est_central: CFG.EST_CENTRAL,
    central:     `${CFG.CENTRAL_HOST}:${CFG.CENTRAL_PORT}`,
    interval:    `${CFG.SYNC_INTERVAL}s`,
});

// Positionner le site_id dans PostgreSQL au démarrage
pool.query(`SET bss.current_site_id = '${CFG.SITE_ID}'`).catch(() => {});

if (!CFG.EST_CENTRAL) {
    // Premier cycle immédiat puis toutes les SYNC_INTERVAL secondes
    syncCycle();
    setInterval(syncCycle, CFG.SYNC_INTERVAL * 1000);
} else {
    info('Mode CENTRAL – en attente des push des sites distants via API');
}

// Arrêt propre
process.on('SIGTERM', async () => {
    info('SIGTERM – arrêt démon sync');
    await pool.end();
    process.exit(0);
});
process.on('SIGINT', async () => {
    info('SIGINT – arrêt démon sync');
    await pool.end();
    process.exit(0);
});

module.exports = { handleSyncPush, handleSyncPull, handleSyncStatus };
