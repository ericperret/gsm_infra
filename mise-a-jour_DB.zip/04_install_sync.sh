#!/usr/bin/env bash
# =============================================================================
# Fichier  : 04_install_sync.sh
# Projet   : BSS Opérateur MCC=547 – Synchronisation multi-sites
# Rôle     : Appliquer le patch SQL, configurer et démarrer bss-sync
# Date     : 2026-05-26
# Version  : 1.0.0
# Cible    : Ubuntu 22.04/24.04 – x86_64
# Usage    : sudo bash 04_install_sync.sh
# =============================================================================

set -euo pipefail

API_DIR="/opt/bss-api"
LOG_FILE="/var/log/bss_sync_install.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }
die() { log "ERREUR : $*"; exit 1; }
ok()  { log "OK – $*"; }

[[ $EUID -ne 0 ]] && die "Exécuter en root (sudo)"

log "=== Installation BSS Sync – MCC=547 ==="

# ─── 1. Saisie des paramètres du nœud ─────────────────────────────────────────
echo ""
echo "=== Configuration du nœud BSS ==="
read -rp "Ce nœud est-il le SERVEUR CENTRAL ? (oui/non) : " IS_CENTRAL

BSS_EST_CENTRAL="false"
BSS_SITE_ID=""

if [[ "$IS_CENTRAL" == "oui" ]]; then
    BSS_EST_CENTRAL="true"
    BSS_SITE_ID="1"
    log "Mode : CENTRAL"
else
    read -rp "ID du site (ex: 2 pour île A, 3 pour île B...) : " BSS_SITE_ID
    [[ ! "$BSS_SITE_ID" =~ ^[2-9][0-9]*$ ]] && die "ID site invalide (entier ≥ 2)"
    log "Mode : SITE DISTANT – id=$BSS_SITE_ID"
fi

read -rp "IP WireGuard du SERVEUR CENTRAL (ex: 10.10.0.1) : " CENTRAL_HOST
read -rp "Token de synchronisation (chaîne secrète partagée) : " SYNC_TOKEN

[[ -z "$SYNC_TOKEN" ]] && die "Token ne peut pas être vide"
[[ -z "$CENTRAL_HOST" ]] && die "IP centrale ne peut pas être vide"

# ─── 2. Patch SQL ─────────────────────────────────────────────────────────────
log "1/4 – Application du patch SQL sync..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -f "${SCRIPT_DIR}/03_bss_sync_schema.sql" ]]; then
    sudo -u postgres psql -v ON_ERROR_STOP=1 \
        -d bss_operateur \
        -f "${SCRIPT_DIR}/03_bss_sync_schema.sql" >> "$LOG_FILE" 2>&1
    ok "Patch SQL appliqué"
else
    die "Fichier 03_bss_sync_schema.sql introuvable dans ${SCRIPT_DIR}"
fi

# ─── 3. Enregistrement du site dans la base ───────────────────────────────────
log "2/4 – Enregistrement du site dans PostgreSQL..."

if [[ "$BSS_EST_CENTRAL" == "false" ]]; then
    # Récupérer l'IP WireGuard locale
    WG_LOCAL_IP=$(ip addr show wg0 2>/dev/null | grep -oP '(?<=inet )\d+\.\d+\.\d+\.\d+' || echo "10.10.0.${BSS_SITE_ID}")

    sudo -u postgres psql -d bss_operateur -c "
    INSERT INTO sites (id_site, nom_site, ip_wg, ip_locale, est_central, sync_token)
    VALUES (${BSS_SITE_ID}, 'Site ${BSS_SITE_ID}', '${WG_LOCAL_IP}', '10.0.0.1', FALSE, '${SYNC_TOKEN}')
    ON CONFLICT (ip_wg) DO UPDATE
        SET sync_token = EXCLUDED.sync_token,
            statut = 'ACTIF',
            date_modification = NOW();
    " >> "$LOG_FILE" 2>&1
    ok "Site ${BSS_SITE_ID} enregistré (IP WG : ${WG_LOCAL_IP})"

    # Configurer le GUC PostgreSQL pour les triggers
    PG_CONF="/etc/postgresql/16/main/postgresql.conf"
    if [[ -f "$PG_CONF" ]]; then
        grep -q "bss.current_site_id" "$PG_CONF" || \
            echo "bss.current_site_id = '${BSS_SITE_ID}'" >> "$PG_CONF"
        grep -q "bss.sync_replication_mode" "$PG_CONF" || \
            echo "bss.sync_replication_mode = 'off'" >> "$PG_CONF"
        systemctl reload postgresql@16-main
        ok "GUC PostgreSQL configuré"
    fi
else
    # Mettre à jour le token du central
    sudo -u postgres psql -d bss_operateur -c "
    UPDATE sites SET sync_token = '${SYNC_TOKEN}' WHERE est_central = TRUE;
    " >> "$LOG_FILE" 2>&1
    ok "Token central mis à jour"
fi

# ─── 4. Variables .env ────────────────────────────────────────────────────────
log "3/4 – Mise à jour ${API_DIR}/.env..."
[[ ! -f "${API_DIR}/.env" ]] && cp "${API_DIR}/.env.example" "${API_DIR}/.env"

# Supprimer les anciennes lignes BSS_* et réécrire
grep -v '^BSS_' "${API_DIR}/.env" > /tmp/bss_env_tmp && mv /tmp/bss_env_tmp "${API_DIR}/.env"

cat >> "${API_DIR}/.env" <<ENV

# ── Synchronisation multi-sites ──────────────────────────────────────────────
BSS_SITE_ID=${BSS_SITE_ID}
BSS_EST_CENTRAL=${BSS_EST_CENTRAL}
BSS_SYNC_TOKEN=${SYNC_TOKEN}
BSS_CENTRAL_HOST=${CENTRAL_HOST}
BSS_CENTRAL_PORT=3000
BSS_CENTRAL_API=http://${CENTRAL_HOST}:3000/api
BSS_WG_PEER_IP=${CENTRAL_HOST}
BSS_CHECK_INTERVAL=30
BSS_SYNC_INTERVAL=120
BSS_RETRY_MAX=5
BSS_BATCH_SIZE=100
ENV

chown bss-api:bss-api "${API_DIR}/.env"
ok ".env mis à jour"

# ─── 5. Copie sync-daemon.js ──────────────────────────────────────────────────
if [[ -f "${SCRIPT_DIR}/sync-daemon.js" ]]; then
    cp "${SCRIPT_DIR}/sync-daemon.js" "${API_DIR}/sync-daemon.js"
    chown bss-api:bss-api "${API_DIR}/sync-daemon.js"
    ok "sync-daemon.js déployé"
fi

# ─── 6. Redémarrage bss-api (qui charge maintenant le sync-daemon) ────────────
log "4/4 – Redémarrage services..."
systemctl restart bss-api
sleep 2
systemctl is-active --quiet bss-api || die "bss-api ne redémarre pas"
ok "bss-api redémarré avec sync activé"

# ─── Vérification ─────────────────────────────────────────────────────────────
sleep 1
STATUS=$(curl -sf "http://127.0.0.1:3000/api/sync/status" || echo '{"success":false}')
log "Sync status : ${STATUS}"

log "======================================================"
log " BSS Sync configuré"
log " Mode        : $([ "$BSS_EST_CENTRAL" == "true" ] && echo "SERVEUR CENTRAL" || echo "SITE DISTANT #${BSS_SITE_ID}")"
log " Central     : ${CENTRAL_HOST}:3000"
log " Intervalle  : 120s"
log " Log sync    : /var/log/bss_sync.log"
log " Status API  : http://127.0.0.1:3000/api/sync/status"
log "======================================================"
