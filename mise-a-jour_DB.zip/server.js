// =============================================================================
// Fichier  : server.js
// Projet   : BSS API – MCC=547 – Opérateur Téléphonie Mobile
// Rôle     : Serveur HTTP Node.js natif – sans framework
// Date     : 2026-05-26
// Version  : 1.1.0 – ajout routes /api/sync/*
// Usage    : node server.js  (ou  npm start)
// =============================================================================

'use strict';

// Chargement .env manuel (pas de dotenv externe)
const fs   = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    fs.readFileSync(envPath, 'utf8')
      .split('\n')
      .forEach(line => {
          const clean = line.trim();
          if (!clean || clean.startsWith('#')) return;
          const eq = clean.indexOf('=');
          if (eq < 0) return;
          const key = clean.slice(0, eq).trim();
          const val = clean.slice(eq + 1).trim().replace(/^["']|["']$/g, '');
          if (!(key in process.env)) process.env[key] = val;
      });
}

const http           = require('http');
const Router         = require('./lib/router');
const { testConnection } = require('./config/db');

// ── Controllers ───────────────────────────────────────────────────────────────
const abonnes    = require('./controllers/abonnes');
const sims       = require('./controllers/sims');
const numeros    = require('./controllers/numeros');
const profils    = require('./controllers/profils');
const evenements = require('./controllers/evenements');

// ── Routeur ───────────────────────────────────────────────────────────────────
const router = new Router();

// ── Santé API ─────────────────────────────────────────────────────────────────
router.get('/api/health', async (req, res) => {
    const { sendJSON } = require('./lib/utils');
    try {
        const pgVersion = await testConnection();
        sendJSON(res, 200, {
            status:    'OK',
            api:       'BSS-MCC547',
            version:   '1.0.0',
            timestamp: new Date().toISOString(),
            postgres:  pgVersion.split(' ').slice(0, 2).join(' '),
        });
    } catch (err) {
        sendJSON(res, 503, { status: 'KO', error: err.message });
    }
});

// ── Abonnés ───────────────────────────────────────────────────────────────────
router.get   ('/api/abonnes',      abonnes.list);
router.get   ('/api/abonnes/:id',  abonnes.getById);
router.post  ('/api/abonnes',      abonnes.create);
router.put   ('/api/abonnes/:id',  abonnes.update);
router.delete('/api/abonnes/:id',  abonnes.remove);

// ── SIM ───────────────────────────────────────────────────────────────────────
router.get('/api/sims',                  sims.list);
router.get('/api/sims/iccid/:iccid',     sims.getByIccid);
router.get('/api/sims/:id',              sims.getById);
router.post('/api/sims',                 sims.create);
router.put ('/api/sims/:id',             sims.update);
router.put ('/api/sims/:id/activer',     sims.activer);
router.put ('/api/sims/:id/bloquer',     sims.bloquer);
router.put ('/api/sims/:id/pin',         sims.resetPin);

// ── Numéros ───────────────────────────────────────────────────────────────────
router.get('/api/numeros',                     numeros.list);
router.get('/api/numeros/msisdn/:msisdn',      numeros.getByMsisdn);
router.get('/api/numeros/:id',                 numeros.getById);
router.post('/api/numeros',                    numeros.create);
router.put ('/api/numeros/:id/attribuer',      numeros.attribuer);
router.put ('/api/numeros/:id/liberer',        numeros.liberer);
router.put ('/api/numeros/:id/porter',         numeros.porter);
router.put ('/api/numeros/:id/suspendre',      numeros.suspendre);

// ── Profils ───────────────────────────────────────────────────────────────────
router.get('/api/profils/abonne/:id_abonne',   profils.listByAbonne);
router.get('/api/profils/:id',                 profils.getById);
router.post('/api/profils',                    profils.create);
router.put ('/api/profils/:id',                profils.update);
router.put ('/api/profils/:id/suspendre',      profils.suspendre);
router.put ('/api/profils/:id/resilier',       profils.resilier);
router.put ('/api/profils/:id/recharger',      profils.recharger);
router.put ('/api/profils/:id/consommer',      profils.consommer);

// ── Synchronisation multi-sites ───────────────────────────────────────────────
const sync = require('./sync-daemon');
router.post('/api/sync/push',   sync.handleSyncPush);
router.get ('/api/sync/pull',   sync.handleSyncPull);
router.get ('/api/sync/status', sync.handleSyncStatus);

// ── Événements / CDR ──────────────────────────────────────────────────────────
router.post('/api/evenements',                       evenements.log);
router.get ('/api/evenements/abonne/:id_abonne',     evenements.listByAbonne);
router.get ('/api/evenements/stats/:id_abonne',      evenements.statsAbonne);
router.get ('/api/evenements/:id',                   evenements.getById);
router.put ('/api/evenements/:id/facturer',          evenements.facturer);

// ── Serveur HTTP ──────────────────────────────────────────────────────────────
const HOST = process.env.HOST || '127.0.0.1';
const PORT = parseInt(process.env.PORT || '3000', 10);

const server = http.createServer((req, res) => {
    // CORS minimal (loopback uniquement en prod)
    res.setHeader('Access-Control-Allow-Origin',  '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    router.handle(req, res);
});

server.listen(PORT, HOST, async () => {
    try {
        const pgVer = await testConnection();
        console.log('╔══════════════════════════════════════════════╗');
        console.log('║      BSS API – MCC=547 – v1.0.0              ║');
        console.log('╠══════════════════════════════════════════════╣');
        console.log(`║  HTTP   : http://${HOST}:${PORT}          ║`);
        console.log(`║  PG     : ${pgVer.split(',')[0].padEnd(36)}║`);
        console.log(`║  PID    : ${String(process.pid).padEnd(36)}║`);
        console.log('╚══════════════════════════════════════════════╝');
    } catch (err) {
        console.error('[FATAL] Connexion PostgreSQL impossible :', err.message);
        process.exit(1);
    }
});

// ── Arrêt propre ──────────────────────────────────────────────────────────────
const { pool } = require('./config/db');

async function shutdown(signal) {
    console.log(`\n[API] Signal ${signal} – arrêt propre...`);
    server.close(async () => {
        await pool.end();
        console.log('[API] Pool PostgreSQL fermé. Bye.');
        process.exit(0);
    });
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
