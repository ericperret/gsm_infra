-- =============================================================================
-- Fichier  : 03_bss_sync_schema.sql
-- Projet   : BSS Opérateur MCC=547 – Synchronisation multi-sites
-- Rôle     : Patch schema – SITES, SYNC_QUEUE, colonnes site_id
-- Date     : 2026-05-26
-- Version  : 1.0.0
-- Prérequis: 02_bss_schema.sql déjà appliqué
-- Usage    : sudo -u postgres psql -d bss_operateur -f 03_bss_sync_schema.sql
-- Topologie:
--   Site insulaire (10.0.0.1)  ←──WireGuard──→  Serveur central (10.0.0.250)
--   PostgreSQL local                              PostgreSQL maître
--   bss-sync-daemon                               bss-sync-daemon (mode central)
-- =============================================================================

\set ON_ERROR_STOP on
\connect bss_operateur

-- =============================================================================
-- TABLE : SITES
-- Référentiel des sites insulaires + serveur central
-- =============================================================================
CREATE TABLE IF NOT EXISTS sites (
    id_site             SERIAL          PRIMARY KEY,
    nom_site            VARCHAR(100)    NOT NULL,
    ile                 VARCHAR(50),
    archipel            VARCHAR(50),
    -- Réseau
    ip_wg               INET            NOT NULL UNIQUE,  -- IP WireGuard (10.10.0.X)
    ip_locale           INET,                             -- IP LAN local (10.0.0.1)
    ip_wan              INET,                             -- IP Starlink (dynamique → NULL)
    -- Rôle
    est_central         BOOLEAN         NOT NULL DEFAULT FALSE,
    -- État sync
    statut              VARCHAR(20)     NOT NULL DEFAULT 'ACTIF'
                                        CHECK (statut IN ('ACTIF','HORS_LIGNE','MAINTENANCE')),
    derniere_sync       TIMESTAMP,
    version_schema      VARCHAR(20)     NOT NULL DEFAULT '1.0.0',
    -- Sécurité sync
    sync_token          VARCHAR(128),   -- token partagé pour authentifier les push
    -- Dates
    date_creation       TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  sites                 IS 'Inventaire des sites insulaires + serveur central';
COMMENT ON COLUMN sites.ip_wg           IS 'IP WireGuard fixe dans le sous-réseau 10.10.0.0/24';
COMMENT ON COLUMN sites.ip_wan          IS 'IP publique Starlink – dynamique, mise à jour par le démon';
COMMENT ON COLUMN sites.sync_token      IS 'Token SHA-256 partagé serveur↔site pour authentifier les syncs';
COMMENT ON COLUMN sites.est_central     IS 'TRUE sur le serveur central (10.0.0.250) uniquement';

-- Seed : serveur central
INSERT INTO sites (nom_site, ile, ip_wg, ip_locale, est_central, sync_token)
VALUES ('Serveur Central', 'Tahiti', '10.10.0.1', '10.0.0.250', TRUE,
        encode(sha256(random()::text::bytea), 'hex'))
ON CONFLICT (ip_wg) DO NOTHING;

CREATE INDEX idx_sites_statut    ON sites (statut);
CREATE INDEX idx_sites_central   ON sites (est_central);

-- =============================================================================
-- COLONNE site_id : ajout sur toutes les tables métier
-- Null = enregistrement du serveur central lui-même
-- =============================================================================
ALTER TABLE abonnes    ADD COLUMN IF NOT EXISTS id_site INT REFERENCES sites(id_site) ON DELETE SET NULL;
ALTER TABLE sims       ADD COLUMN IF NOT EXISTS id_site INT REFERENCES sites(id_site) ON DELETE SET NULL;
ALTER TABLE numeros    ADD COLUMN IF NOT EXISTS id_site INT REFERENCES sites(id_site) ON DELETE SET NULL;
ALTER TABLE profils    ADD COLUMN IF NOT EXISTS id_site INT REFERENCES sites(id_site) ON DELETE SET NULL;
ALTER TABLE evenements ADD COLUMN IF NOT EXISTS id_site INT REFERENCES sites(id_site) ON DELETE SET NULL;

COMMENT ON COLUMN abonnes.id_site    IS 'Site d''origine – NULL = serveur central';
COMMENT ON COLUMN evenements.id_site IS 'Site qui a généré le CDR';

CREATE INDEX IF NOT EXISTS idx_abonnes_site    ON abonnes    (id_site) WHERE id_site IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_evenements_site ON evenements (id_site) WHERE id_site IS NOT NULL;

-- =============================================================================
-- TABLE : SYNC_QUEUE
-- File d'attente de synchronisation locale → centrale
-- Chaque écriture locale est empilée ici et poussée quand le WireGuard est UP
-- =============================================================================
CREATE TABLE IF NOT EXISTS sync_queue (
    id_sync             BIGSERIAL       PRIMARY KEY,
    id_site             INT             NOT NULL
                                        REFERENCES sites(id_site) ON DELETE CASCADE,
    -- Opération
    table_cible         VARCHAR(50)     NOT NULL,
    operation           CHAR(1)         NOT NULL
                                        CHECK (operation IN ('I','U','D')),  -- Insert/Update/Delete
    record_id           BIGINT          NOT NULL,   -- PK de l'enregistrement source
    -- Payload JSON complet de la ligne (pour rejeu sur le central)
    payload             JSONB           NOT NULL,
    -- État
    statut              VARCHAR(20)     NOT NULL DEFAULT 'EN_ATTENTE'
                                        CHECK (statut IN ('EN_ATTENTE','EN_COURS','SYNCED','ERREUR','CONFLIT')),
    nb_tentatives       SMALLINT        NOT NULL DEFAULT 0,
    derniere_tentative  TIMESTAMP,
    message_erreur      TEXT,
    -- Identifiant unique côté central pour détection des doublons
    central_id          BIGINT,
    -- Timestamps
    date_creation       TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_sync           TIMESTAMP
);

COMMENT ON TABLE  sync_queue                IS 'File d''attente synchro site → central – persistée sur disque';
COMMENT ON COLUMN sync_queue.operation      IS 'I=INSERT, U=UPDATE, D=DELETE';
COMMENT ON COLUMN sync_queue.payload        IS 'Snapshot JSON complet de la ligne au moment de l''opération';
COMMENT ON COLUMN sync_queue.statut         IS 'EN_ATTENTE → poussé quand WireGuard UP';
COMMENT ON COLUMN sync_queue.central_id     IS 'ID attribué par le central après réception – évite les doublons';

CREATE INDEX idx_sync_site_statut    ON sync_queue (id_site, statut);
CREATE INDEX idx_sync_en_attente     ON sync_queue (statut, date_creation)
    WHERE statut = 'EN_ATTENTE';
CREATE INDEX idx_sync_erreur         ON sync_queue (statut, nb_tentatives)
    WHERE statut = 'ERREUR';

-- =============================================================================
-- TABLE : SYNC_LOG
-- Journal des sessions de synchronisation (une ligne par sync complète)
-- =============================================================================
CREATE TABLE IF NOT EXISTS sync_log (
    id_log              SERIAL          PRIMARY KEY,
    id_site             INT             NOT NULL
                                        REFERENCES sites(id_site),
    direction           VARCHAR(10)     NOT NULL
                                        CHECK (direction IN ('PUSH','PULL','FULL')),
    statut              VARCHAR(20)     NOT NULL DEFAULT 'OK'
                                        CHECK (statut IN ('OK','PARTIEL','ERREUR')),
    nb_envoyes          INT             NOT NULL DEFAULT 0,
    nb_recus            INT             NOT NULL DEFAULT 0,
    nb_conflits         INT             NOT NULL DEFAULT 0,
    nb_erreurs          INT             NOT NULL DEFAULT 0,
    duree_ms            INT,
    detail              JSONB,                      -- résumé par table
    date_debut          TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_fin            TIMESTAMP
);

COMMENT ON TABLE sync_log IS 'Journal des sessions de synchronisation – une ligne par run';

CREATE INDEX idx_synclog_site ON sync_log (id_site, date_debut DESC);

-- =============================================================================
-- TRIGGERS : alimenter SYNC_QUEUE automatiquement sur INSERT/UPDATE/DELETE
-- Activés uniquement sur les sites distants (pas sur le central)
-- Le démon positionne un flag GUC local pour désactiver pendant la réplication
-- =============================================================================
CREATE OR REPLACE FUNCTION fn_sync_enqueue()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
    v_id_site INT;
    v_record_id BIGINT;
    v_payload JSONB;
    v_operation CHAR(1);
    v_pk_col TEXT;
BEGIN
    -- Ne pas empiler si on est en mode réplication (flag GUC positionné par le démon)
    IF current_setting('bss.sync_replication_mode', TRUE) = 'on' THEN
        RETURN COALESCE(NEW, OLD);
    END IF;

    -- Récupérer l'id_site courant (configuré par le démon au démarrage)
    v_id_site := current_setting('bss.current_site_id', TRUE)::INT;
    IF v_id_site IS NULL OR v_id_site = 0 THEN
        RETURN COALESCE(NEW, OLD);  -- Site non configuré → pas de sync
    END IF;

    -- Déterminer l'opération
    v_operation := CASE TG_OP
        WHEN 'INSERT' THEN 'I'
        WHEN 'UPDATE' THEN 'U'
        WHEN 'DELETE' THEN 'D'
    END;

    -- Payload et record_id selon l'opération
    IF TG_OP = 'DELETE' THEN
        v_payload    := to_jsonb(OLD);
        v_record_id  := (v_payload->>'id_'||TG_TABLE_NAME)::BIGINT;
    ELSE
        v_payload    := to_jsonb(NEW);
        -- Récupérer la PK (colonne id_<table>)
        v_record_id  := CASE TG_TABLE_NAME
            WHEN 'abonnes'    THEN NEW.id_abonne
            WHEN 'sims'       THEN NEW.id_sim
            WHEN 'numeros'    THEN NEW.id_numero
            WHEN 'profils'    THEN NEW.id_profil
            WHEN 'evenements' THEN NEW.id_evenement
            ELSE NULL
        END;
    END IF;

    IF v_record_id IS NOT NULL THEN
        INSERT INTO sync_queue (id_site, table_cible, operation, record_id, payload)
        VALUES (v_id_site, TG_TABLE_NAME, v_operation, v_record_id, v_payload);
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Attacher le trigger sur chaque table métier
DO $$
DECLARE tbl TEXT;
BEGIN
    FOREACH tbl IN ARRAY ARRAY['abonnes','sims','numeros','profils','evenements'] LOOP
        EXECUTE format(
            'DROP TRIGGER IF EXISTS tg_%s_sync ON %s;
             CREATE TRIGGER tg_%s_sync
               AFTER INSERT OR UPDATE OR DELETE ON %s
               FOR EACH ROW EXECUTE FUNCTION fn_sync_enqueue();',
            tbl, tbl, tbl, tbl
        );
    END LOOP;
END;
$$;

-- =============================================================================
-- FONCTION : statistiques de sync (utilisée par l'API /api/sync/status)
-- =============================================================================
CREATE OR REPLACE FUNCTION fn_sync_stats(p_id_site INT DEFAULT NULL)
RETURNS TABLE (
    id_site         INT,
    nom_site        VARCHAR,
    en_attente      BIGINT,
    en_erreur       BIGINT,
    synced_24h      BIGINT,
    derniere_sync   TIMESTAMP,
    statut_site     VARCHAR
) LANGUAGE sql AS $$
    SELECT
        s.id_site,
        s.nom_site,
        COUNT(q.id_sync) FILTER (WHERE q.statut = 'EN_ATTENTE')  AS en_attente,
        COUNT(q.id_sync) FILTER (WHERE q.statut = 'ERREUR')      AS en_erreur,
        COUNT(q.id_sync) FILTER (WHERE q.statut = 'SYNCED'
                                   AND q.date_sync >= NOW() - INTERVAL '24 hours') AS synced_24h,
        s.derniere_sync,
        s.statut                                                  AS statut_site
    FROM sites s
    LEFT JOIN sync_queue q ON q.id_site = s.id_site
    WHERE (p_id_site IS NULL OR s.id_site = p_id_site)
      AND s.est_central = FALSE
    GROUP BY s.id_site, s.nom_site, s.derniere_sync, s.statut
    ORDER BY s.id_site;
$$;

-- =============================================================================
-- DROITS bss_admin sur les nouvelles tables
-- =============================================================================
GRANT SELECT, INSERT, UPDATE, DELETE ON sites, sync_queue, sync_log TO bss_admin;
GRANT USAGE, SELECT ON SEQUENCE sync_queue_id_sync_seq, sync_log_id_log_seq, sites_id_site_seq TO bss_admin;

-- =============================================================================
-- VÉRIFICATION
-- =============================================================================
DO $$
DECLARE nb INT;
BEGIN
    SELECT COUNT(*) INTO nb FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name IN ('sites','sync_queue','sync_log');
    IF nb < 3 THEN
        RAISE EXCEPTION 'Patch incomplet : % tables sur 3 attendues', nb;
    END IF;
    RAISE NOTICE '===================================================';
    RAISE NOTICE ' Patch sync BSS appliqué avec succès';
    RAISE NOTICE ' Nouvelles tables : sites, sync_queue, sync_log';
    RAISE NOTICE ' Triggers sync    : abonnes, sims, numeros, profils, evenements';
    RAISE NOTICE ' Colonne site_id  : ajoutée sur toutes les tables métier';
    RAISE NOTICE '===================================================';
END;
$$;
