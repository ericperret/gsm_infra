-- =============================================================================
-- Fichier  : 02_bss_schema.sql
-- Projet   : BSS Opérateur Téléphonie Mobile – MCC=547 (Polynésie française)
-- Étape    : 1/3 – Schéma base bss_operateur
-- Auteur   : BSS-Admin
-- Date     : 2026-05-26
-- Version  : 1.0.0
-- SGBD     : PostgreSQL 16 – UTF-8 – Timezone : Pacific/Tahiti
-- Usage    : sudo -u postgres psql -d bss_operateur -f 02_bss_schema.sql
-- =============================================================================

\set ON_ERROR_STOP on
\connect bss_operateur

-- ─── Extensions ───────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS unaccent;
CREATE EXTENSION IF NOT EXISTS pg_trgm;     -- recherche floue sur noms/adresses

-- =============================================================================
-- TABLE : OPERATEURS
-- Référence des opérateurs (MCC/MNC). Supporte plusieurs MNC par MCC.
-- =============================================================================
CREATE TABLE IF NOT EXISTS operateurs (
    id_operateur        SERIAL          PRIMARY KEY,
    mcc                 CHAR(3)         NOT NULL DEFAULT '547'
                                        CHECK (mcc ~ '^\d{3}$'),
    mnc                 CHAR(2)         NOT NULL
                                        CHECK (mnc ~ '^\d{2}$'),
    nom_operateur       VARCHAR(100)    NOT NULL,
    nom_court           VARCHAR(20),
    pays                VARCHAR(100)    NOT NULL DEFAULT 'Polynésie française',
    code_pays_iso2      CHAR(2)         NOT NULL DEFAULT 'PF',
    code_pays_iso3      CHAR(3)         NOT NULL DEFAULT 'PYF',
    indicatif_pays      VARCHAR(5)      NOT NULL DEFAULT '+689',
    statut              VARCHAR(20)     NOT NULL DEFAULT 'ACTIF'
                                        CHECK (statut IN ('ACTIF','SUSPENDU','INACTIF')),
    date_creation       TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_mcc_mnc UNIQUE (mcc, mnc)
);

COMMENT ON TABLE  operateurs              IS 'Référentiel des opérateurs – MCC/MNC';
COMMENT ON COLUMN operateurs.mcc          IS 'Mobile Country Code – 547 = Polynésie française';
COMMENT ON COLUMN operateurs.mnc          IS 'Mobile Network Code – identifiant réseau';

-- Seed : opérateur principal
INSERT INTO operateurs (mcc, mnc, nom_operateur, nom_court)
VALUES ('547', '20', 'Opérateur BSS Principal', 'BSS-PF')
ON CONFLICT (mcc, mnc) DO NOTHING;

-- =============================================================================
-- TABLE : ABONNES
-- Titulaires de contrat – particuliers, entreprises, MVNO, prépayés.
-- =============================================================================
CREATE TABLE IF NOT EXISTS abonnes (
    id_abonne           SERIAL          PRIMARY KEY,
    id_operateur        INT             NOT NULL
                                        REFERENCES operateurs(id_operateur)
                                        ON DELETE RESTRICT,
    type_client         VARCHAR(20)     NOT NULL
                                        CHECK (type_client IN (
                                            'PARTICULIER','ENTREPRISE',
                                            'MVNO','PREPAYE','ADMINISTRATION')),
    -- Identité
    nom                 VARCHAR(100)    NOT NULL,
    prenom              VARCHAR(100),
    raison_sociale      VARCHAR(200),                   -- entreprises/admin
    date_naissance      DATE,
    type_piece_id       VARCHAR(20)
                                        CHECK (type_piece_id IN (
                                            'CNI','PASSEPORT','TITRE_SEJOUR',
                                            'KBIS','NIF',NULL)),
    numero_piece_id     VARCHAR(50),
    -- Coordonnées
    adresse_ligne1      VARCHAR(200),
    adresse_ligne2      VARCHAR(200),
    ville               VARCHAR(100),
    code_postal         VARCHAR(10),
    ile                 VARCHAR(50),                    -- spécifique Polynésie
    archipel            VARCHAR(50),                    -- Societe, Tuamotu, Marquises...
    email               VARCHAR(150),
    telephone_contact   VARCHAR(20),
    -- Gestion
    statut              VARCHAR(20)     NOT NULL DEFAULT 'ACTIF'
                                        CHECK (statut IN (
                                            'ACTIF','SUSPENDU','RESILIÉ',
                                            'EN_ATTENTE','BLOQUÉ_FRAUDE')),
    score_credit        SMALLINT        DEFAULT 100
                                        CHECK (score_credit BETWEEN 0 AND 100),
    date_creation       TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW(),
    -- Contrainte métier
    CONSTRAINT chk_identite CHECK (
        nom IS NOT NULL AND (
            (type_client = 'ENTREPRISE'   AND raison_sociale IS NOT NULL) OR
            (type_client = 'ADMINISTRATION' AND raison_sociale IS NOT NULL) OR
            (type_client NOT IN ('ENTREPRISE','ADMINISTRATION'))
        )
    )
);

COMMENT ON TABLE  abonnes                 IS 'Titulaires de contrat – tous types clients';
COMMENT ON COLUMN abonnes.ile             IS 'Île de résidence – spécifique Polynésie française';
COMMENT ON COLUMN abonnes.archipel        IS 'Archipel : Société, Tuamotu, Marquises, Gambier, Australes';

CREATE INDEX idx_abonnes_operateur    ON abonnes (id_operateur);
CREATE INDEX idx_abonnes_statut       ON abonnes (statut);
CREATE INDEX idx_abonnes_nom_trgm     ON abonnes USING GIN (nom gin_trgm_ops);
CREATE INDEX idx_abonnes_email        ON abonnes (email) WHERE email IS NOT NULL;

-- =============================================================================
-- TABLE : SIMS
-- Cartes SIM physiques et eSIM – clé IMSI liée au MCC=547.
-- =============================================================================
CREATE TABLE IF NOT EXISTS sims (
    id_sim              SERIAL          PRIMARY KEY,
    id_abonne           INT             REFERENCES abonnes(id_abonne)
                                        ON DELETE SET NULL,
    -- Identifiants réseau
    iccid               VARCHAR(22)     NOT NULL UNIQUE
                                        CHECK (iccid ~ '^\d{19,22}$'),
    imsi                VARCHAR(15)     NOT NULL UNIQUE
                                        CHECK (imsi ~ '^547\d{9,12}$'),  -- MCC=547
    -- Caractéristiques physiques
    type_sim            VARCHAR(10)     NOT NULL DEFAULT '4G'
                                        CHECK (type_sim IN ('2G','3G','4G','5G','ESIM')),
    format_sim          VARCHAR(10)     NOT NULL DEFAULT 'NANO'
                                        CHECK (format_sim IN ('FULL','MINI','MICRO','NANO','ESIM')),
    lot_fabrication     VARCHAR(50),
    -- Statut
    statut              VARCHAR(20)     NOT NULL DEFAULT 'STOCK'
                                        CHECK (statut IN (
                                            'STOCK','ACTIVÉE','SUSPENDUE',
                                            'RÉSILIÉE','BLOQUÉE','PERDUE','VOLÉE')),
    -- Sécurité (ne jamais exposer Ki en clair – stocker hashé ou via HSS)
    ki_hash             VARCHAR(128),               -- SHA-512 du Ki
    -- Compteurs PIN
    tentatives_pin1     SMALLINT        NOT NULL DEFAULT 0
                                        CHECK (tentatives_pin1 BETWEEN 0 AND 3),
    tentatives_pin2     SMALLINT        NOT NULL DEFAULT 0
                                        CHECK (tentatives_pin2 BETWEEN 0 AND 3),
    pin1_bloque         BOOLEAN         NOT NULL DEFAULT FALSE,
    pin2_bloque         BOOLEAN         NOT NULL DEFAULT FALSE,
    -- Dates
    date_fabrication    DATE,
    date_activation     TIMESTAMP,
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  sims                    IS 'Inventaire des SIM physiques et eSIM';
COMMENT ON COLUMN sims.imsi               IS 'IMSI – commence obligatoirement par 547 (MCC)';
COMMENT ON COLUMN sims.ki_hash            IS 'Clé d'authentification – stockée en hash SHA-512 uniquement';

CREATE INDEX idx_sims_abonne      ON sims (id_abonne) WHERE id_abonne IS NOT NULL;
CREATE INDEX idx_sims_statut      ON sims (statut);
CREATE INDEX idx_sims_iccid       ON sims (iccid);

-- =============================================================================
-- TABLE : NUMEROS
-- MSISDN au format E.164 – gestion du stock, attribution, portabilité.
-- =============================================================================
CREATE TABLE IF NOT EXISTS numeros (
    id_numero           SERIAL          PRIMARY KEY,
    msisdn              VARCHAR(15)     NOT NULL UNIQUE
                                        CHECK (msisdn ~ '^\+689\d{6,8}$'),  -- +689 Polynésie
    id_abonne           INT             REFERENCES abonnes(id_abonne)
                                        ON DELETE SET NULL,
    id_sim              INT             REFERENCES sims(id_sim)
                                        ON DELETE SET NULL,
    -- Classification
    type_numero         VARCHAR(20)     NOT NULL DEFAULT 'MOBILE'
                                        CHECK (type_numero IN (
                                            'MOBILE','FIXE_MOBILE','SERVICE',
                                            'PREMIUM','URGENCE','M2M')),
    -- Statut
    statut              VARCHAR(20)     NOT NULL DEFAULT 'DISPONIBLE'
                                        CHECK (statut IN (
                                            'DISPONIBLE','ATTRIBUÉ','SUSPENDU',
                                            'RÉSILIÉ','PORTÉ_ENTRANT',
                                            'PORTÉ_SORTANT','RÉSERVÉ','QUARANTAINE')),
    -- Portabilité
    operateur_source    VARCHAR(100),               -- MNP entrante : opérateur d'origine
    operateur_cible     VARCHAR(100),               -- MNP sortante : opérateur receveur
    -- Dates
    date_attribution    TIMESTAMP,
    date_resiliation    TIMESTAMP,
    date_portabilite    TIMESTAMP,
    date_fin_quarantaine TIMESTAMP,                 -- 90 j après résiliation
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW(),
    -- Règle métier : MSISDN attribué → abonné obligatoire
    CONSTRAINT chk_attribution CHECK (
        (statut = 'ATTRIBUÉ' AND id_abonne IS NOT NULL) OR
        statut != 'ATTRIBUÉ'
    )
);

COMMENT ON TABLE  numeros                 IS 'Stock et attribution des numéros MSISDN – E.164 +689';
COMMENT ON COLUMN numeros.msisdn          IS 'Format E.164 – indicatif Polynésie française : +689';
COMMENT ON COLUMN numeros.statut          IS 'QUARANTAINE : 90 jours après résiliation avant réattribution';

CREATE INDEX idx_numeros_abonne   ON numeros (id_abonne)  WHERE id_abonne IS NOT NULL;
CREATE INDEX idx_numeros_sim      ON numeros (id_sim)     WHERE id_sim IS NOT NULL;
CREATE INDEX idx_numeros_statut   ON numeros (statut);

-- =============================================================================
-- TABLE : PROFILS
-- Offres et forfaits rattachés aux abonnés (un abonné peut avoir N profils).
-- =============================================================================
CREATE TABLE IF NOT EXISTS profils (
    id_profil           SERIAL          PRIMARY KEY,
    id_abonne           INT             NOT NULL
                                        REFERENCES abonnes(id_abonne)
                                        ON DELETE CASCADE,
    -- Offre commerciale
    code_offre          VARCHAR(30)     NOT NULL,
    nom_offre           VARCHAR(100)    NOT NULL,
    type_forfait        VARCHAR(20)     NOT NULL
                                        CHECK (type_forfait IN (
                                            'PREPAYE','POSTPAYE','HYBRIDE',
                                            'M2M','DATA_ONLY','VOIX_ONLY')),
    -- Quotas (0 = illimité)
    data_quota_mo       BIGINT          NOT NULL DEFAULT 0
                                        CHECK (data_quota_mo >= 0),
    data_consomme_mo    BIGINT          NOT NULL DEFAULT 0
                                        CHECK (data_consomme_mo >= 0),
    voix_minutes        INT             NOT NULL DEFAULT 0
                                        CHECK (voix_minutes >= 0),
    voix_consomme_min   INT             NOT NULL DEFAULT 0
                                        CHECK (voix_consomme_min >= 0),
    sms_quota           INT             NOT NULL DEFAULT 0
                                        CHECK (sms_quota >= 0),
    sms_consomme        INT             NOT NULL DEFAULT 0
                                        CHECK (sms_consomme >= 0),
    -- Options
    roaming_actif       BOOLEAN         NOT NULL DEFAULT FALSE,
    vvm_actif           BOOLEAN         NOT NULL DEFAULT FALSE,
    wifi_calling        BOOLEAN         NOT NULL DEFAULT FALSE,
    volte_actif         BOOLEAN         NOT NULL DEFAULT FALSE,
    -- Facturation
    tarif_mensuel       NUMERIC(10,2)   NOT NULL DEFAULT 0.00
                                        CHECK (tarif_mensuel >= 0),
    devise              CHAR(3)         NOT NULL DEFAULT 'XPF',   -- Franc CFP
    solde_prepaye       NUMERIC(12,2)   DEFAULT 0.00,             -- prépayé uniquement
    -- Validité
    statut              VARCHAR(20)     NOT NULL DEFAULT 'ACTIF'
                                        CHECK (statut IN (
                                            'ACTIF','SUSPENDU','EXPIRÉ','RÉSILIÉ')),
    date_debut          DATE            NOT NULL,
    date_fin            DATE,
    date_renouvellement DATE,
    date_creation       TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_validite_dates CHECK (
        date_fin IS NULL OR date_fin >= date_debut
    )
);

COMMENT ON TABLE  profils                 IS 'Offres et forfaits des abonnés – postpayé, prépayé, M2M';
COMMENT ON COLUMN profils.data_quota_mo   IS 'Quota data en Mo – 0 = illimité';
COMMENT ON COLUMN profils.devise          IS 'XPF = Franc CFP (Polynésie française)';
COMMENT ON COLUMN profils.solde_prepaye   IS 'Solde en XPF – utilisé pour type_forfait = PREPAYE';

CREATE INDEX idx_profils_abonne   ON profils (id_abonne);
CREATE INDEX idx_profils_statut   ON profils (statut);
CREATE INDEX idx_profils_offre    ON profils (code_offre);

-- =============================================================================
-- TABLE : EVENEMENTS
-- CDR (Call Detail Records) – tous types d'événements facturables.
-- Partitionnée par mois sur date_evenement pour les volumes opérateur.
-- =============================================================================
CREATE TABLE IF NOT EXISTS evenements (
    id_evenement        BIGSERIAL       NOT NULL,
    id_abonne           INT             NOT NULL
                                        REFERENCES abonnes(id_abonne)
                                        ON DELETE RESTRICT,
    id_numero           INT             REFERENCES numeros(id_numero)
                                        ON DELETE SET NULL,
    id_profil           INT             REFERENCES profils(id_profil)
                                        ON DELETE SET NULL,
    -- Type d'événement
    type_evenement      VARCHAR(25)     NOT NULL
                                        CHECK (type_evenement IN (
                                            'APPEL_SORTANT','APPEL_ENTRANT',
                                            'SMS_SORTANT','SMS_ENTRANT',
                                            'DATA_SESSION',
                                            'ROAMING_VOIX','ROAMING_DATA','ROAMING_SMS',
                                            'RECHARGE','AJUSTEMENT',
                                            'FACTURATION','TRANSFERT')),
    -- Détail événement
    numero_correspondant VARCHAR(20),              -- numéro appelé/appelant
    cellule_id          VARCHAR(30),               -- Cell-ID / eNodeB ID
    plmn_visite         VARCHAR(6),                -- MCCMNC réseau visité (roaming)
    -- Métriques
    duree_secondes      INT             NOT NULL DEFAULT 0
                                        CHECK (duree_secondes >= 0),
    volume_ko           BIGINT          NOT NULL DEFAULT 0
                                        CHECK (volume_ko >= 0),
    -- Facturation
    montant             NUMERIC(14,4)   NOT NULL DEFAULT 0.0000
                                        CHECK (montant >= 0),
    devise              CHAR(3)         NOT NULL DEFAULT 'XPF',
    statut_facturation  VARCHAR(20)     NOT NULL DEFAULT 'A_FACTURER'
                                        CHECK (statut_facturation IN (
                                            'A_FACTURER','FACTURÉ','OFFERT',
                                            'ERREUR','ANNULÉ','LITIGIEUX')),
    -- Timestamps
    date_evenement      TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_traitement     TIMESTAMP,
    -- PK composite pour partitionnement futur
    PRIMARY KEY (id_evenement, date_evenement)
) PARTITION BY RANGE (date_evenement);

COMMENT ON TABLE  evenements                      IS 'CDR – Call Detail Records, tous événements facturables';
COMMENT ON COLUMN evenements.plmn_visite          IS 'MCCMNC du réseau visité en itinérance (roaming)';
COMMENT ON COLUMN evenements.statut_facturation   IS 'LITIGIEUX : contesté par l''abonné';

-- Partitions initiales (6 mois courants)
CREATE TABLE evenements_2026_01 PARTITION OF evenements
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');
CREATE TABLE evenements_2026_02 PARTITION OF evenements
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');
CREATE TABLE evenements_2026_03 PARTITION OF evenements
    FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');
CREATE TABLE evenements_2026_04 PARTITION OF evenements
    FOR VALUES FROM ('2026-04-01') TO ('2026-05-01');
CREATE TABLE evenements_2026_05 PARTITION OF evenements
    FOR VALUES FROM ('2026-05-01') TO ('2026-06-01');
CREATE TABLE evenements_2026_06 PARTITION OF evenements
    FOR VALUES FROM ('2026-06-01') TO ('2026-07-01');

CREATE INDEX idx_evt_abonne  ON evenements (id_abonne, date_evenement);
CREATE INDEX idx_evt_numero  ON evenements (id_numero)  WHERE id_numero IS NOT NULL;
CREATE INDEX idx_evt_type    ON evenements (type_evenement, date_evenement);
CREATE INDEX idx_evt_statut  ON evenements (statut_facturation) WHERE statut_facturation = 'A_FACTURER';

-- =============================================================================
-- TABLE : ALERTES_CBS
-- Cell Broadcast Service – diffusion d'alertes réseau (tsunamis, cyclones…).
-- =============================================================================
CREATE TABLE IF NOT EXISTS alertes_cbs (
    id_alerte           SERIAL          PRIMARY KEY,
    id_operateur        INT             NOT NULL
                                        REFERENCES operateurs(id_operateur)
                                        ON DELETE RESTRICT,
    -- Identifiants CBS (3GPP TS 23.041)
    message_id          INT             NOT NULL
                                        CHECK (message_id BETWEEN 0 AND 65535),
    canal_cbs           INT             NOT NULL
                                        CHECK (canal_cbs BETWEEN 0 AND 65535),
    -- 4370–4399 : EU-Alert / FR-Alert
    -- 4352-4354 : Earthquake / Tsunami (ETWS)
    -- Classification
    categorie           VARCHAR(20)     NOT NULL DEFAULT 'INFO'
                                        CHECK (categorie IN (
                                            'URGENCE_EXTREME',   -- Niveau 1 (rouge)
                                            'URGENCE_SEVERE',    -- Niveau 2 (orange)
                                            'AMBER',             -- alerte enlèvement
                                            'TSUNAMI','SEISME',  -- ETWS
                                            'CYCLONE','INONDATION',
                                            'TEST','INFO','COMMERCIAL')),
    priorite            SMALLINT        NOT NULL DEFAULT 0
                                        CHECK (priorite BETWEEN 0 AND 3),
    -- Ciblage géographique
    zone_description    VARCHAR(200),
    lac_list            TEXT,                          -- liste LAC/TAC séparés par virgule
    cellules_list       TEXT,                          -- ciblage cellule fin
    -- Contenu multilingue
    message_fr          TEXT            NOT NULL,
    message_en          TEXT,
    message_ty          TEXT,                          -- Tahitien (Reo Māʻohi)
    -- Diffusion
    nb_repetitions      SMALLINT        NOT NULL DEFAULT 3
                                        CHECK (nb_repetitions BETWEEN 1 AND 99),
    periode_repetition_s INT            NOT NULL DEFAULT 60
                                        CHECK (periode_repetition_s >= 0),
    -- Cycle de vie
    statut              VARCHAR(20)     NOT NULL DEFAULT 'DRAFT'
                                        CHECK (statut IN (
                                            'DRAFT','VALIDÉ','PLANIFIÉ',
                                            'EN_DIFFUSION','TERMINÉ','ANNULÉ')),
    validateur          VARCHAR(100),                  -- login du validateur
    operateur_envoi     VARCHAR(100),                  -- login du déclencheur
    date_planification  TIMESTAMP,
    date_emission       TIMESTAMP,
    date_expiration     TIMESTAMP,
    date_creation       TIMESTAMP       NOT NULL DEFAULT NOW(),
    date_modification   TIMESTAMP       NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_cbs_dates CHECK (
        date_expiration IS NULL OR
        date_expiration > COALESCE(date_emission, date_planification, NOW())
    )
);

COMMENT ON TABLE  alertes_cbs               IS 'Cell Broadcast Service – alertes Polynésie (tsunamis, cyclones…)';
COMMENT ON COLUMN alertes_cbs.canal_cbs     IS '4370-4399 : FR-Alert / EU-Alert | 4352-4354 : ETWS Séisme/Tsunami';
COMMENT ON COLUMN alertes_cbs.message_ty    IS 'Message en Reo Māʻohi (Tahitien) – langue officielle Polynésie';
COMMENT ON COLUMN alertes_cbs.lac_list      IS 'LAC/TAC ciblés, virgule-séparés – vide = diffusion nationale';

CREATE INDEX idx_cbs_operateur    ON alertes_cbs (id_operateur);
CREATE INDEX idx_cbs_statut       ON alertes_cbs (statut);
CREATE INDEX idx_cbs_emission     ON alertes_cbs (date_emission) WHERE date_emission IS NOT NULL;
CREATE INDEX idx_cbs_categorie    ON alertes_cbs (categorie);

-- =============================================================================
-- TRIGGERS : mise à jour automatique date_modification
-- =============================================================================
CREATE OR REPLACE FUNCTION fn_maj_date_modification()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.date_modification = NOW();
    RETURN NEW;
END;
$$;

CREATE TRIGGER tg_operateurs_modif
    BEFORE UPDATE ON operateurs
    FOR EACH ROW EXECUTE FUNCTION fn_maj_date_modification();

CREATE TRIGGER tg_abonnes_modif
    BEFORE UPDATE ON abonnes
    FOR EACH ROW EXECUTE FUNCTION fn_maj_date_modification();

CREATE TRIGGER tg_sims_modif
    BEFORE UPDATE ON sims
    FOR EACH ROW EXECUTE FUNCTION fn_maj_date_modification();

CREATE TRIGGER tg_numeros_modif
    BEFORE UPDATE ON numeros
    FOR EACH ROW EXECUTE FUNCTION fn_maj_date_modification();

CREATE TRIGGER tg_profils_modif
    BEFORE UPDATE ON profils
    FOR EACH ROW EXECUTE FUNCTION fn_maj_date_modification();

CREATE TRIGGER tg_alertes_cbs_modif
    BEFORE UPDATE ON alertes_cbs
    FOR EACH ROW EXECUTE FUNCTION fn_maj_date_modification();

-- =============================================================================
-- DROITS : bss_admin sur toutes les tables et séquences
-- =============================================================================
GRANT USAGE ON SCHEMA public TO bss_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES    IN SCHEMA public TO bss_admin;
GRANT USAGE, SELECT                  ON ALL SEQUENCES IN SCHEMA public TO bss_admin;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES    TO bss_admin;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT USAGE, SELECT                  ON SEQUENCES TO bss_admin;

-- =============================================================================
-- VÉRIFICATION FINALE
-- =============================================================================
DO $$
DECLARE
    nb_tables INT;
BEGIN
    SELECT COUNT(*) INTO nb_tables
    FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_type   = 'BASE TABLE'
      AND table_name IN (
          'operateurs','abonnes','sims','numeros',
          'profils','evenements','alertes_cbs'
      );

    IF nb_tables < 7 THEN
        RAISE EXCEPTION 'Schéma incomplet : % tables créées sur 7 attendues', nb_tables;
    END IF;

    RAISE NOTICE '====================================================';
    RAISE NOTICE ' Schéma BSS MCC=547 créé avec succès';
    RAISE NOTICE ' Tables : % (7 attendues)', nb_tables;
    RAISE NOTICE ' Base   : bss_operateur';
    RAISE NOTICE ' TZ     : Pacific/Tahiti (UTC-10)';
    RAISE NOTICE '====================================================';
END;
$$;
