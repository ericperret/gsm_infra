#!/usr/bin/env bash
# =============================================================================
# Fichier  : 01_install_postgresql.sh
# Projet   : BSS Opérateur Téléphonie Mobile – MCC=547
# Étape    : 1/3 – Installation PostgreSQL + création base bss_operateur
# Auteur   : BSS-Admin
# Date     : 2026-05-26
# Version  : 1.0.0
# Cible    : Ubuntu 22.04/24.04 LTS – x86_64
# Usage    : sudo bash 01_install_postgresql.sh
# =============================================================================

set -euo pipefail

# ─── Variables ────────────────────────────────────────────────────────────────
DB_NAME="bss_operateur"
DB_USER="bss_admin"
DB_PASS="Bss@547#Secure"          # À changer en production
PG_VERSION="16"
SQL_SCHEMA="02_bss_schema.sql"
LOG_FILE="/var/log/bss_install.log"

# ─── Fonctions utilitaires ────────────────────────────────────────────────────
log()  { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }
die()  { log "ERREUR : $*"; exit 1; }
ok()   { log "OK – $*"; }

# ─── Vérifications préalables ─────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && die "Ce script doit être exécuté en root (sudo)"

ARCH=$(uname -m)
[[ "$ARCH" != "x86_64" ]] && die "Architecture non supportée : $ARCH (x86_64 requis)"

OS_ID=$(grep -oP '(?<=^ID=).+' /etc/os-release | tr -d '"')
[[ "$OS_ID" != "ubuntu" ]] && die "Distribution non supportée : $OS_ID (Ubuntu requis)"

log "=== Démarrage installation BSS PostgreSQL – MCC=547 ==="

# ─── 1. Mise à jour système ───────────────────────────────────────────────────
log "1/7 – Mise à jour des paquets système..."
apt-get update -qq && apt-get upgrade -y -qq
ok "Système à jour"

# ─── 2. Dépendances ───────────────────────────────────────────────────────────
log "2/7 – Installation des dépendances..."
apt-get install -y -qq \
    curl \
    ca-certificates \
    gnupg \
    lsb-release \
    wget
ok "Dépendances installées"

# ─── 3. Dépôt officiel PostgreSQL ─────────────────────────────────────────────
log "3/7 – Ajout du dépôt officiel PostgreSQL ${PG_VERSION}..."

install -d /usr/share/postgresql-common/pgdg
curl -fsSL "https://www.postgresql.org/media/keys/ACCC4CF8.asc" \
    -o /usr/share/postgresql-common/pgdg/apt.postgresql.org.asc

CODENAME=$(lsb_release -cs)
cat > /etc/apt/sources.list.d/pgdg.list <<EOF
deb [signed-by=/usr/share/postgresql-common/pgdg/apt.postgresql.org.asc] \
https://apt.postgresql.org/pub/repos/apt ${CODENAME}-pgdg main
EOF

apt-get update -qq
ok "Dépôt PostgreSQL configuré (${CODENAME})"

# ─── 4. Installation PostgreSQL ───────────────────────────────────────────────
log "4/7 – Installation de PostgreSQL ${PG_VERSION}..."
apt-get install -y -qq \
    "postgresql-${PG_VERSION}" \
    "postgresql-client-${PG_VERSION}" \
    "postgresql-contrib-${PG_VERSION}"

systemctl enable "postgresql@${PG_VERSION}-main"
systemctl start  "postgresql@${PG_VERSION}-main"

sleep 2
systemctl is-active --quiet "postgresql@${PG_VERSION}-main" \
    || die "PostgreSQL ne démarre pas"
ok "PostgreSQL ${PG_VERSION} installé et démarré"

# ─── 5. Création utilisateur et base ─────────────────────────────────────────
log "5/7 – Création de l'utilisateur '${DB_USER}' et de la base '${DB_NAME}'..."

sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
-- Utilisateur applicatif BSS
DO \$\$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${DB_USER}') THEN
        CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASS}';
    END IF;
END
\$\$;

-- Base de données
SELECT 'CREATE DATABASE ${DB_NAME} 
    OWNER      ${DB_USER}
    ENCODING   ''UTF8''
    LC_COLLATE ''fr_FR.UTF-8''
    LC_CTYPE   ''fr_FR.UTF-8''
    TEMPLATE   template0'
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = '${DB_NAME}')
\gexec

-- Privilèges
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
SQL

ok "Base '${DB_NAME}' et utilisateur '${DB_USER}' créés"

# ─── 6. Configuration pg_hba.conf ────────────────────────────────────────────
log "6/7 – Configuration des accès pg_hba.conf..."

PG_HBA="/etc/postgresql/${PG_VERSION}/main/pg_hba.conf"
PG_CONF="/etc/postgresql/${PG_VERSION}/main/postgresql.conf"

# Accès local par mot de passe pour bss_admin
if ! grep -q "bss_admin" "$PG_HBA"; then
    sed -i "/^local   all             all/a local   ${DB_NAME}    ${DB_USER}                              md5" "$PG_HBA"
fi

# Écoute localhost uniquement (sécurité de base)
sed -i "s/^#listen_addresses = 'localhost'/listen_addresses = 'localhost'/" "$PG_CONF"

# Paramètres perf minimaux pour BSS
cat >> "$PG_CONF" <<PGCONF

# ── BSS Opérateur MCC=547 – Tuning minimal ──────────────────────
shared_buffers        = 256MB
effective_cache_size  = 1GB
work_mem              = 16MB
maintenance_work_mem  = 128MB
wal_level             = replica
log_timezone          = 'Pacific/Tahiti'
timezone              = 'Pacific/Tahiti'
datestyle             = 'iso, dmy'
# ────────────────────────────────────────────────────────────────
PGCONF

systemctl reload "postgresql@${PG_VERSION}-main"
ok "pg_hba.conf et postgresql.conf configurés"

# ─── 7. Application du schéma SQL ────────────────────────────────────────────
log "7/7 – Application du schéma BSS (${SQL_SCHEMA})..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -f "${SCRIPT_DIR}/${SQL_SCHEMA}" ]]; then
    sudo -u postgres psql -v ON_ERROR_STOP=1 \
        -d "$DB_NAME" \
        -f "${SCRIPT_DIR}/${SQL_SCHEMA}" \
        >> "$LOG_FILE" 2>&1
    ok "Schéma appliqué avec succès"
else
    log "ATTENTION : fichier ${SQL_SCHEMA} introuvable – schéma non appliqué"
    log "Exécuter manuellement : sudo -u postgres psql -d ${DB_NAME} -f ${SQL_SCHEMA}"
fi

# ─── Récapitulatif ────────────────────────────────────────────────────────────
log "======================================================"
log " Installation terminée"
log " PostgreSQL : ${PG_VERSION}"
log " Base       : ${DB_NAME}"
log " Utilisateur: ${DB_USER}"
log " Log        : ${LOG_FILE}"
log " Vérif      : sudo -u postgres psql -d ${DB_NAME} -c '\\dt'"
log "======================================================"
